# src/models/user.py

from dataclasses import dataclass
from bson import ObjectId


@dataclass
class User:
    id: str
    username: str
    email: str

    @staticmethod
    def from_mongo(document):
        """Convert MongoDB document to User instance"""
        if not document:
            return None
        return User(
            id=str(document.get("_id")),
            username=document.get("username"),
            email=document.get("email")
        )

    @staticmethod
    def to_mongo(user_data):
        """Convert dict/User to MongoDB-friendly format"""
        mongo_data = {
            "username": user_data.get("username"),
            "email": user_data.get("email"),
        }
        return mongo_data
